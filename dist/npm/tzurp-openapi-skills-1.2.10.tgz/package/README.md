
# openapi-skills: OpenAPI & GraphQL CLI

Looking for the Pro version? → https://github.com/tzurp/openapi-skills-pro
[![Pro version](https://img.shields.io/badge/openapi--skills--pro-Repository-blue)](https://github.com/tzurp/openapi-skills-pro)

`openapi-skills` is an OpenAPI CLI and GraphQL CLI for exploring APIs, generating artifacts, validating schemas, and preparing live API requests. Its optional AI agent skills enable Copilot, Claude, Cursor, and other agents to use the CLI through natural language.

![Legacy downloads](https://img.shields.io/badge/Legacy%20downloads-5347-blue)
![openapi-skills downloads](https://img.shields.io/badge/dynamic/json?url=https://api.npmjs.org/downloads/point/2020-01-01:2030-01-01/@tzurp/openapi-skills&query=$.downloads&label=Current%20downloads&color=blue)
<p align="center">
<img src="https://raw.githubusercontent.com/tzurp/images/refs/heads/main/openapi-skills.png">
</p>

<h3 align="center"> A powerful command‑line toolkit for working with OpenAPI and GraphQL schemas.  
Use it manually like a fast, lightweight API explorer, or unlock its full potential by installing the built‑in Skill bundle, which teaches AI agents (Copilot, Claude, Cursor, etc.) how to operate the CLI through natural language.</h3>

With Skills enabled, openapi‑skills becomes an AI‑ready API engine: agents can explore your API, prepare and execute live requests, validate schemas, and even generate client code, tests, and workflows - all from simple, conversational instructions.

## Quick links

- [Install the CLI](#install-the-cli)
- [Install the AI skill bundle](#install-the-skill)
- [Quick start](#quick-start)
- [AI agent examples](#ai-agent-integration)
- [Video demo](#-video-demo)
- [Support and issues](#support)

## Overview: OpenAPI & GraphQL CLI

`openapi-skills` helps developers work with API schemas efficiently. It parses OpenAPI and GraphQL definitions, generates structured artifacts, provides exploration tools, validates schemas, prepares request templates, and supports test generation. When the AI skills are installed, agents can understand your API and execute CLI commands automatically.

## Why openapi-skills

Working with API schemas can be slow and error‑prone. `openapi-skills` provides:

- A consistent way to explore any API  
- Automatic artifact generation  
- Request templates you can execute immediately  
- Built‑in validation tools  
- Optional AI integration for natural-language workflows  

## Free vs. Pro: Choosing the right tool for your workflow

The free CLI is perfect for solo developers, quick exploration, and everyday API work.  
The Pro CLI is built for teams, automation, and production‑grade workflows, where speed, orchestration, and tooling depth matter.  
Here’s a concise comparison to help you understand where each version shines:

### Comparison Table
| **Scenario / Workflow** | **Free CLI** | **Pro CLI** |
| --- | --- | --- |
| **Explore OpenAPI & GraphQL schemas** | ✔ Explore OpenAPI 2.0 / 3.0.x & GraphQL schemas | ✔ Same, with OpenAPI 3.1 support |
| **Generate artifacts** | ✔ endpoints.json, schemas/ | ✔ Extended artifacts for docs, diffing & analysis |
| **Validate schemas** | ✔ Built‑in validation | ✔ Deep validation + version comparison |
| **Prepare & execute live API requests** | ✔ Postman‑like request builder | ✔ Same, plus mock‑server integration |
| **AI agent workflows** | ✔ Optional skill bundle for LLM agents | ✔ Enhanced Skills (OpenAPI annotation generation) |
| **Mock server** | — | ✔ Local mock server from schema artifacts |
| **HTML API documentation** | — | ✔ Generate interactive HTML docs |
| **Schema diffing / version comparison** | — | ✔ Operation‑level diffing & breaking‑change detection |
| **Code‑first OpenAPI generation** | — | ✔ Bootstrap OpenAPI from annotated source code |
| **Distribution** | ``npm install -g`` | Native installers (Windows/macOS/Linux) |

## Manual CLI + AI Skills

openapi-skills works perfectly as a traditional CLI. You can explore endpoints, inspect schemas, prepare requests, and execute live API calls directly from the terminal.

Enable the optional Skill bundle, and AI agents (Copilot, Claude, Cursor, etc.) can operate the CLI for you: exploring operations, preparing and executing requests, validating schemas, and even generating client code, tests, and multi-step workflows from natural language.

## Features

- Explore operations by method, path, tag, or keyword  
- Describe endpoints with full request/response details  
- Prepare and execute live API requests (Postman‑like, no code needed)  
- Parse OpenAPI 2.0/3.x and GraphQL schemas  
- Generate artifacts (`endpoints.json`, `schemas/`)
- Work with multiple API schemas simultaneously (stored under: .openapi-skills/<apiName>/ directory)
- Validate schemas and API responses  
- Build multi-step scenarios  
- AI Skills bundle for agent-driven workflows (code, tests, clients, docs)

## Workflow

**parse → index → understand → execute → validate → generate code/tests (via agent)**

## Quick start

### Install the CLI

```bash
npm install -g @tzurp/openapi-skills
```

### Install the Skill

```bash
openapi-skills install --skills
```
Select your preferred path from  the menu and confirm

### Generate artifacts from a schema

```bash
openapi-skills generate https://petstore.swagger.io/v2/swagger.json --base-url=https://petstore.swagger.io/v2
```

This creates:

```
.openapi-skills/
  petstore/
    endpoints.json
    schemas/
```

### Explore the API manually

```bash
openapi-skills list --api petstore --method POST --index 0:10
openapi-skills list --api petstore --method GET --path /pet --tag pet
openapi-skills describe addPet --api petstore
```

### Prepare and execute a request manually

```bash
openapi-skills request addPet --api petstore --force --update-request '{"body.id":1,"body.name":"Fluffy"}'
```

---

## ⚡ One‑line agent command

Once the Skills bundle is installed, the entire Quick start can be replaced with a single natural-language instruction:

```
In Agent mode write: /openapi-skill make live request to addPet with name "Fluffy" using the schema https://petstore.swagger.io/v2/swagger.json and base url https://petstore.swagger.io/v2
```

The agent will:

- Parse the schema  
- Generate artifacts  
- Index endpoints  
- Prepare the request  
- Set `"name": "Fluffy"`  
- Execute it live  
- Show the response  

All from **one sentence**.

### Example questions you can ask the Skill if you feel stuck

You can always ask the skill question to progress in your work. For example:
 - `/openapi-skills what can you do?`
 - `/openapi-skills how do I add an auth token to a live request?`

---

## 5‑minute tutorial

### 1. Install the CLI

```bash
npm install -g @tzurp/openapi-skills
```

### Install the Skill

```bash
# Local install (default)
openapi-skills install --skills
```
```bash
# Global install (user home)
openapi-skills install --skills --global
```

During installation, the CLI shows a small menu where you choose the Skill’s location:

- `.cursor/skills/`
- `.agent/skills/`
- `.claude/skills/`
- `.github/skills/`
- `other` (custom path)

Select your preferred path and confirm — that’s it.

> **💡 Note:**
>
> Installing the skill bundle allows AI agents to understand your API structure and execute CLI commands automatically.  
> See the section on [AI agent capabilities](#ai-agent-integration).


### 2. Parse a public API and set its base URL

```bash
openapi-skills generate https://petstore.swagger.io/v2/swagger.json --base-url=https://petstore.swagger.io/v2 --rename petstore-v2
```

### 3. Explore operations

```bash
openapi-skills list --api petstore --method POST --index 0
openapi-skills describe addPet --api petstore
```

### 4. Build and execute a request

```bash
openapi-skills request addPet --api petstore --force --update-request '{"body.id":1,"body.name":"Fluffy"}'
```

### 5. Validate the schema

```bash
openapi-skills generate https://petstore.swagger.io/v2/swagger.json --validate
```

## AI agent integration

The optional skill bundle teaches AI agents how to operate this API CLI using natural-language instructions. With the skill enabled, agents can:

- Explore OpenAPI and GraphQL schemas and API operations
- Generate client code, tests, documentation, and other artifacts
- Prepare and execute live API requests
- Validate schemas and API responses
- Build multi-step API workflows

### AI agent examples

| Natural language request | CLI/Skill executed |
|--------------------------|--------------------|
| "/openapi-skills Make a live request to addPet with name Fluffy." | Postman‑like API call via `request --update-request` |
| "/openapi-skills Show me the first POST operation." | Explore endpoints via `list` |
| "/openapi-skills Describe the addPet operation." | Operation breakdown via `describe` |
| "/openapi-skills Validate this API schema." | Schema validation via `generate --validate` |
| "/openapi-skills Generate a Jest test for addPet." | Agent writes full Jest test using CLI metadata |
| "/openapi-skills Create a Playwright API test for addPet." | Agent generates Playwright test using endpoint + schema |
| "/openapi-skills Build a TypeScript API client for this API." | Agent generates typed client functions + models |
| "/openapi-skills Create a 3-step scenario: add, fetch, delete pet." | Multi-step workflow via `request` |

Agents combine CLI output with code generation to produce:
- typed API clients  
- integration & contract tests  
- Playwright API tests  
- mocks & fixtures  
- multi-step workflows  
- documentation  

## 🎥 Video demo

A short video clip demonstrating the CLI in action is available here:

[https://github.com/tzurp/openapi-skills-cli/releases/tag/video](https://github.com/tzurp/openapi-skills-cli/releases/tag/video)

## Support

If you run into issues or have questions:

- Report bugs or request features via GitHub Issues: [https://github.com/tzurp/openapi-skills-cli/issues](https://github.com/tzurp/openapi-skills-cli/issues)
- General questions can be sent directly to: [tzur.paldi@outlook.com](mailto:tzur.paldi@outlook.com)
- Check CLI help for up-to-date usage:
  ```bash
  openapi-skills --help
  openapi-skills <command> --help
  ```

> **✨TIP**
>
> When opening an issue or sending an email, include the CLI version, the command you ran, and any relevant logs or schema snippets.

## Links

- npm package: [https://www.npmjs.com/package/@tzurp/openapi-skills](https://www.npmjs.com/package/@tzurp/openapi-skills)
- GitHub repository: [https://github.com/tzurp/openapi-skills-cli](https://github.com/tzurp/openapi-skills-cli)
- Bedekbyte: [https://www.bedekbyte.com](https://www.bedekbyte.com)

## npm package release (maintainers)

Run `npm run package:npm` to build and test the project, bundle the CLI into a minified `dist/cli.min.js` using esbuild, and create an npm tarball under `dist/npm/`. Publish the generated tarball with `npm publish <tarball-path>`. This npm packaging flow is separate from `publish-to-public.bat`.
